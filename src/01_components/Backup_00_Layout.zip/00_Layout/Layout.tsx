import styles from './Layout.module.css';

function Layout({ children }: { children: React.ReactNode; }) {
  return (
    <div className={styles.Layout}>
      {/* Layout Area */}
      <header className={styles['LayoutHeader']}>
        <div className={styles['Logo']}>
          NFT TRADER
        </div>
        <nav>
          <a href="/">Main</a>
          <a href="/NftMarketPage">Nft_Market</a>
        </nav>
      </header>
      <main className={styles['LayoutMain']}>
        {children}
      </main>
      <footer className={styles['LayoutFooter']}>
        <p>© 2025 hyunwoo park. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default Layout;